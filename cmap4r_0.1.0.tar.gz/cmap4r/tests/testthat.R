library(testthat)

test_check("cmap4r")
